<?php
require_once "../../global.php";
$VIEW_NAME = "./home.php";
require_once "../index.php";
