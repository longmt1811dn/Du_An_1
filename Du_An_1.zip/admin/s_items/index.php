<?php 
require_once "../../global.php";
$VIEW_NAME="list.php";
require_once "../index.php";
?>