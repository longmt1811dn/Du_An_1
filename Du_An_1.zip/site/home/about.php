<main class="main">
        <nav class="collection__nav">
                <div class="collection__nav-text center-center">
                        <h1>Giới thiệu</h1>
                </div>
        </nav>


        <div class="introduct" id="introduct">
                <!-- đổ dữ liệu từ js -->

        </div>
</main>

<script src="./assets/js/member.js"></script>