$(document).ready(function () {
  $(".owl-carousel").owlCarousel({
    items: 1,
    // autoplay
    // autoplay: true,
    // autoplayTimeout: 5000,

    loop: true,
    nav:true,
  });
});
